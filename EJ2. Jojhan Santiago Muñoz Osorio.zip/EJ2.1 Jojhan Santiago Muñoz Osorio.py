def numeros_descendente():
    print("\nBienvenido Estimado Usuario.")
    
    n1 = int(input("Ingresa un número: "))
    
    print(f"Los números de {n1} a 1 son:")
    num = n1
    while num >= 1:
        print(num, end=" ")
        num = num - 1
    
    print("\nFin")

numeros_descendente()
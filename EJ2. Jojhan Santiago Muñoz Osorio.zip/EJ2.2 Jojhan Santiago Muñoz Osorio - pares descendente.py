'''
Universidad Escuela Colombiana de Ingeniería
Profesora: Ingeniera Patricia Salazar Perdomo

Estudiante: Apellidos Nombre

Lenguaje: Python
Referencia: Ejercicios No. 2. Python básico.
            Estructuras de control condicionales if y while.

2.  Escribir los números pares que pertenecen al intervalo [a, b], a y b enteros, en orden descendente.
    Ejemplo. Intervalo [28, 39]
    Los pares que pertenecen al intervalo [28, 39], en orden descendente, son:
    38  36  34  32  30  28
'''

def pares_desc():
    print("\nBienvenido estimado usuario.")
    n1 = int(input("Escribe el número menor del intervalo: "))
    n2 = int(input("Escribe el número mayor del intervalo: "))

    if n2 % 2 != 0:
        n2 = n2 - 1

    par = n2
    while par >= n1:
        print(par, end=" ")
        par = par - 2

    print("\n\nGracias por usar el programa.")

pares_desc()

'''
Universidad Escuela Colombiana de Ingeniería
Profesora: Ingeniera Patricia Salazar Perdomo

Estudiante: Apellidos Nombre

Lenguaje: Python
Referencia: Ejercicios No. 2. Python básico.
            Estructuras de control condicionales if y while.

3. Pedir un número entero n, suponer que es positivo, y averiguar cuántos divisores tiene, diferentes a 1 y al mismo número.
    Ejemplo 1.	n igual a 24
                El número 24 tiene 6 divisores.
		Nota. Los divisores son 2, 3, 4, 6, 8 y 12. No hay que escribirlos.
    Ejemplo 2.	n igual a 126
                El número 126 tiene 10 divisores.
'''

def divisores ( ):
    print ("\nBienvenido al programa.")
    n1=int(input("Escribe un numero entero positivo para averiguar sus divisores"))
    divisor=2
    cont=0
    if n1 % divisor==0:
        cont=cont+1
        divisor=divisor+1
        print
    print (f"\nLos números {n1} y el número de divisores es {cont}.")
print("Gracias por usa el program")
divisores ( )   

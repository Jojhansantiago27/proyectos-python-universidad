'''
Universidad Escuela Colombiana de Ingeniería
Asignatura: Introducción a la Programación (IPRO)
Profesora: Ingeniera Patricia Salazar Perdomo

Estudiante: Apellidos Nombre

Lenguaje: Python
Referencia: Ejercicios No. 2. Python básico.
            Estructuras de control condicionales if y while.

4. El cementerio Jardines del Descanso tiene una floristería que ofrece ramos
   sólo en una de tres flores: rosas, anturios o tulipanes. Cada ramo de una
   flor tiene un precio diferente.

   Pedir a c clientes la cantidad de ramos de cada flor que desea comprar
   (puede que sea cero). 

   Se quiere saber
   - Cantidad de ramos que se vendieron de cada flor.
   - Total recaudado por la venta de los ramos según la flor.

'''

def ventas_floristeria ( ):
    print ("\nCementerio Jardines del Descanso")
    c = int(input("¿Cuántos clientes van a comprar? "))
   
    total_rosas = 0
    total_tulipanes = 0
    total_anturios = 0
    cliente = 1
    while cliente <= c:
        print(f"\nCliente {cliente}:")
        rosas = int(input("  ¿Cuántas rosas quiere? "))
        tulipanes = int(input("  ¿Cuántos tulipanes quiere? "))
        anturios = int(input("  ¿Cuántos anturios quiere? "))
        total_rosas = total_rosas + rosas
        total_tulipanes = total_tulipanes + tulipanes
        total_anturios = total_anturios + anturios
        cliente=cliente+1
    precio_rosas=float(input("\nPrecio de un ramo de rosas:$"))
    precio_tulipanes=float(input("\nPrecio de un ramo de tulipanes:$"))
    precio_anturios=float(input("\nPrecio de un ramo de anturios:$"))
    print(f"\nSe vendieron {total_rosas} ramos de rosas. Total: ${total_rosas * precio_rosas}")
    print(f"Se vendieron {total_tulipanes} ramos de tulipanes. Total: ${total_tulipanes * precio_tulipanes}")
    print(f"Se vendieron {total_anturios} ramos de anturios. Total: ${total_anturios * precio_anturios}")
 
    print ("\nFin")
        
ventas_floristeria ( )   

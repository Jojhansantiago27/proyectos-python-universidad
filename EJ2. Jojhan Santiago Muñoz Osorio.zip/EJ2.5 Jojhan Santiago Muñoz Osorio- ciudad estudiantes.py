'''
Universidad Escuela Colombiana de Ingeniería
Profesora: Ingeniera Patricia Salazar Perdomo

Estudiante: Apellidos Nombre

Lenguaje: Python

Referencia: Python básico. Estructuras de control condicionales if y while.

5. La mayoría de los e estudiantes de pregrado de la Universidad Escuela Colombiana
   de Ingeniería (Escuela) son de Bogotá. Se quiere saber:

   a. Cuántos de ellos son de Bogotá (1), cuántos de los alrededores (2) y cuántos de otros lugares del país o de otros países (3). Suponga que el usuario ingresa 1, 2 o 3, únicamente, para responder a la pregunta.
   b. A qué porcentaje corresponde cada cantidad.
   c. Valor de la matrícula promedio que pagan los estudiantes de Bogotá.

   Ejemplo:
   Cantidad de estudiantes de la Escuela: 4350

   Ejemplo de resultado:

   Población de la Escuela: 4350
   Bogotá: 3600 (82.8 %)
   Alrededores: 485 (11.1 %)
   Otros lugares del país o de otros países: 265 (6.1 %)

   El valor de la matrícula promedio que pagan los estudiantes de Bogotá es
   $10,385,000.

   Recuérdese que los resultados deben ser claros, concisos y completos.

'''
def origen_escuela():
    print("\nEncuesta - origen - estudiantes de pregrado de la Escuela.")
    cant_est = int(input("\nCantidad de estudiantes de pregrado de la Escuela "))
    
    Estudiante = 1
    cant_estBog = 0
    cant_estAlrededores = 0
    cant_estOtro = 0
    suma_matriculas_bog = 0  

    while Estudiante <= cant_est:
        print(f"\nEstudiante {Estudiante}:")
        Origen = int(input("¿De dónde es? (1=Bogotá, 2=Alrededores, 3=Otros): "))

        if Origen == 1:
            cant_estBog = cant_estBog + 1
            matricula = float(input("  Valor de su matrícula: $"))
            suma_matriculas_bog = suma_matriculas_bog + matricula
        elif Origen == 2:
            cant_estAlrededores = cant_estAlrededores + 1
        elif Origen == 3:
            cant_estOtro = cant_estOtro + 1

        Estudiante = Estudiante + 1

    
    porcentaje_bogota = (cant_estBog / cant_est) * 100
    porcentaje_alrededor = (cant_estAlrededores / cant_est) * 100
    porcentaje_otro = (cant_estOtro / cant_est) * 100

    if cant_estBog > 0:
        promedio_matricula_bog = suma_matriculas_bog / cant_estBog
    else:
        promedio_matricula_bog = 0

    print("\nRESULTADOS:")
    print(f"Población de la Escuela: {cant_est}")
    print(f"Bogotá: {cant_estBog} ({porcentaje_bogota:.1f} %)")
    print(f"Alrededores: {cant_estAlrededores} ({porcentaje_alrededor:.1f} %)")
    print(f"Otros lugares del país o de otros países: {cant_estOtro} ({porcentaje_otro:.1f} %)")
    print(f"\nEl valor de la matrícula promedio que pagan los estudiantes de Bogotá es ${promedio_matricula_bog:,.0f}.")
    print("\nFin.\n\n")

origen_escuela()
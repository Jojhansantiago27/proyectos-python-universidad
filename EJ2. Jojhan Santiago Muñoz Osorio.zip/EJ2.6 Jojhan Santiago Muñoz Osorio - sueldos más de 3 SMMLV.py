'''
Universidad Escuela Colombiana de Ingeniería
Profesora: Ingeniera Patricia Salazar Perdomo
Estudiante: Apellidos Nombre
Lenguaje: Python
Referencia: Ejercicios No. 2. Python básico.

6. Hallar y escribir el promedio de n sueldos que superen 3 SMMLV ($1,750,905).
'''

def salarios_mas_3_minimos():
    print("\nBienvenido Estimado Usuario.")
    
    SMMLV = 1750905
    limite = SMMLV * 3
    
    n = int(input("¿Cuántos sueldos como mínimo va a ingresar? "))
    
    suma_altos = 0
    cant_altos = 0
    contador = 1

    while contador <= n:
        sueldo = float(input(f"Ingresa el sueldo #{contador}: "))
        
        if sueldo > limite:
            suma_altos = suma_altos + sueldo
            cant_altos = cant_altos + 1
        
        contador = contador + 1
   
    seguir = input("¿Desea ingresar otro sueldo? (s/n): ")
    
    while seguir == "s":
        sueldo = float(input(f"Ingresa el sueldo #{contador}: "))
        
        if sueldo > limite:
            suma_altos = suma_altos + sueldo
            cant_altos = cant_altos + 1
        
        contador = contador + 1
        seguir = input("¿Desea ingresar otro sueldo? (s/n): ")
    
    print("\nMENSAJE DE FINALIZACIÓN.")
    
    if cant_altos > 0:
        promedio = suma_altos / cant_altos
        print(f"El promedio de los {cant_altos} sueldos ingresados, mayores que 3 veces el SMMLV (${SMMLV}), es ${promedio:,.0f}.")
    else:
        print("Ningún sueldo ingresado superó 3 veces el SMMLV.")

salarios_mas_3_minimos()
